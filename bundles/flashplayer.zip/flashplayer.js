(function() {
    const flashPlayerAppTemplate = `
        <appcontentholder class="flashplayer-ruffle-app" style="display: flex; flex-direction: column; height: 100%; overflow: hidden; background: radial-gradient(circle, #D82020, #A01010);">
            
            <div style="flex-grow: 1; position: relative; overflow: hidden;">
                <iframe id="ruffle-iframe" style="position: absolute; top: 0; left: 0; width:100%; height:100%; border:none; display:none;" allowfullscreen></iframe>
                
                <div id="flash-open-prompt" style="position: absolute; top: 0; left: 0; width:100%; height:100%; display: flex; flex-direction: column; align-items: center; justify-content: center; color: white; padding: 20px; box-sizing: border-box; z-index: 2;">
                    <img src="res/icons/flash_player.png" alt="Flash Player" style="width:64px; height:64px; margin-bottom:20px;">
                    <winbutton id="flash-open-swf-btn"><btnopt>Open SWF File...</btnopt></winbutton>
                </div>
            </div>

            <div id="flash-player-footer" style="padding: 5px; text-align: center; color: rgba(255, 255, 255, 0.8); background-color: rgba(0, 0, 0, 0.2); border-top: 1px solid rgba(0,0,0,0.3); flex-shrink: 0;">
                Adobe® and Flash® Player are trademarks of Adobe Inc.<br>
                Quenq and Reborn XP is not affiliated with or approved by Adobe.<br>
                For entertainment and educational purposes only. Powered by Ruffle.
            </div>
        </appcontentholder>
    `;

    let currentHWnd = null;
    let currentBlobUrl = null;

    async function setupRuffleIframe(iframe) {
        return new Promise((resolve) => {
            const doc = iframe.contentDocument || iframe.contentWindow.document;
            doc.open();
            doc.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body { margin: 0; padding: 0; overflow: hidden; background-color: transparent; width: 100vw; height: 100vh; }
                        #player-container { width: 100%; height: 100%; }
                    </style>
                    <script src="res/js/ruffle/ruffle.js"><\/script>
                </head>
                <body>
                    <div id="player-container"></div>
                </body>
                </html>
            `);
            doc.close();

            let attempts = 0;
            const interval = setInterval(() => {
                const win = iframe.contentWindow;
                if (win && win.RufflePlayer && win.RufflePlayer.newest) {
                    clearInterval(interval);
                    resolve(win.RufflePlayer.newest());
                } else if (attempts > 100) {
                    clearInterval(interval);
                    resolve(null);
                }
                attempts++;
            }, 100);
        });
    }

    async function loadSwfIntoPlayer(filePath, iframe) {
        if (!iframe) return;

        const openPrompt = iframe.parentElement.querySelector('#flash-open-prompt');
        const footer = iframe.closest('appcontentholder').querySelector('#flash-player-footer');
        
        try {
            openPrompt.style.display = 'none';
            if (footer) footer.style.display = 'none';
            iframe.style.display = 'block';

            const ruffleInstance = await setupRuffleIframe(iframe);
            if (!ruffleInstance) throw new Error("Ruffle failed to load in isolated context.");

            const node = await dm.open(filePath);
            if (!node || !node.content) throw new Error("File not found in VFS");
            
            if (currentBlobUrl) URL.revokeObjectURL(currentBlobUrl);
            currentBlobUrl = URL.createObjectURL(node.content);

            const player = ruffleInstance.createPlayer();
            const container = iframe.contentDocument.getElementById('player-container');
            
            container.innerHTML = '';
            container.appendChild(player);
            
            await player.load({ url: currentBlobUrl });

            if (currentHWnd) wm.setCaption(currentHWnd, `${dm.basename(filePath)} - Adobe Flash Player`);

            if (window.SystemGamepad) {
                window.SystemGamepad.show();
            }

        } catch (error) {
            console.error("Flash Player Error:", error);
            dialogHandler.spawnDialog({
                icon: "error", title: "Flash Player Error",
                text: `Could not load SWF file "${dm.basename(filePath)}":<br>${error.message}`
            });
            
            if (window.SystemGamepad) window.SystemGamepad.hide();

            openPrompt.style.display = 'flex';
            if (footer) footer.style.display = 'block';
            iframe.style.display = 'none';
            if (currentHWnd) wm.setCaption(currentHWnd, "Adobe Flash Player");
        }
    }

    async function openSwfDialogFromApp(iframe) {
        const filePath = await wm.openFileDialog({
            title: "Open SWF File - Adobe Flash Player",
            filters: [{ name: "Shockwave Flash (*.swf)", extensions: ["swf"] }]
        });
        if (filePath) {
            await loadSwfIntoPlayer(filePath, iframe);
        }
    }

    window.registerApp({
        _template: null,
        setup: async function() {
            this._template = document.createElement("template");
            this._template.innerHTML = flashPlayerAppTemplate;
        },

        start: async function(options = {}) {
            const windowContents = this._template.content.firstElementChild.cloneNode(true);
            currentHWnd = wm.createNewWindow("FlashPlayerRuffle", windowContents);
            
            const iframe = windowContents.querySelector('#ruffle-iframe');
            const openPromptDiv = windowContents.querySelector('#flash-open-prompt');
            const openSwfButton = windowContents.querySelector('#flash-open-swf-btn');
            const footer = windowContents.querySelector('#flash-player-footer');

            if (options.icon) {
                 wm.setIcon(currentHWnd, options.icon);
            }
           
            wm.setCaption(currentHWnd, "Adobe Flash Player");
            wm.setSize(currentHWnd, 550, 400);

            if (openSwfButton && iframe) {
                openSwfButton.onclick = () => openSwfDialogFromApp(iframe);
            }

            const swfFileToLoad = (options && options.filePath && options.filePath.toLowerCase().endsWith('.swf')) ? options.filePath : null;

            if (swfFileToLoad) {
                loadSwfIntoPlayer(swfFileToLoad, iframe);
            } else {
                openPromptDiv.style.display = 'flex';
                if (footer) footer.style.display = 'block';
                iframe.style.display = 'none';
                
                if (window.SystemGamepad) window.SystemGamepad.hide();
            }

            const selfWindow = wm._windows[currentHWnd];
            if (selfWindow) {
                selfWindow.addEventListener('wm:windowClosed', () => {
                    if (window.SystemGamepad) {
                        window.SystemGamepad.hide();
                    }

                    if (currentBlobUrl) {
                        URL.revokeObjectURL(currentBlobUrl);
                        currentBlobUrl = null;
                    }
                    currentHWnd = null; 
                }, { once: true });
            }

            return currentHWnd;
        },

        handleNewData: async function(options = {}) {
             if (options.filePath && currentHWnd && wm._windows[currentHWnd]) {
                const iframe = wm._windows[currentHWnd].querySelector('#ruffle-iframe');
                await loadSwfIntoPlayer(options.filePath, iframe);
                wm.focusWindow(currentHWnd);
            }
        }
    });
})();