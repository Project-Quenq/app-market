(function () {
  const windowTemplate = `
        <appcontentholder style="background-color: #000; overflow: hidden; display: flex; align-items: center; justify-content: center;">
            <iframe id="ruffle-iframe" style="width: 100%; height: 100%; border: none;"></iframe>
        </appcontentholder>
    `;

  registerApp({
    _template: null,
    _currentBlobUrl: null,

    setup: async function () {
      this._template = document.createElement("template");
      this._template.innerHTML = windowTemplate;
    },

    start: async function (options) {
      const installPath = options.installPath;
      if (!installPath) {
        dialogHandler.spawnDialog({
          icon: "error",
          title: "Error",
          text: "This app must be installed to locate its files.",
        });
        return;
      }

      const windowContents =
        this._template.content.firstElementChild.cloneNode(true);
      const hWnd = wm.createNewWindow("swf-wrapper", windowContents);

      wm.setCaption(hWnd, "Bubble Trouble");
      wm.setSize(hWnd, 550, 400);

      if (options.icon) {
        wm.setIcon(hWnd, options.icon);
      }

      const iframe = windowContents.querySelector("#ruffle-iframe");

      try {
        await new Promise((resolve) => {
          iframe.onload = resolve;
          iframe.srcdoc = `
                        <!DOCTYPE html>
                        <html>
                        <head>
                            <style>body { margin: 0; overflow: hidden; }</style>
                            <script src="/res/js/ruffle/ruffle.js"></script>
                        </head>
                        <body></body>
                        </html>
                    `;
        });

        await new Promise((resolve, reject) => {
          let attempts = 0;
          const interval = setInterval(() => {
            if (iframe.contentWindow && iframe.contentWindow.RufflePlayer) {
              clearInterval(interval);
              resolve();
            } else if (attempts > 50) {
              clearInterval(interval);
              reject(
                new Error("Ruffle player did not load inside the iframe."),
              );
            }
            attempts++;
          }, 100);
        });

        const ruffle = iframe.contentWindow.RufflePlayer.newest();
        const player = ruffle.createPlayer();
        iframe.contentDocument.body.appendChild(player);

        const swfPath = dm.join(installPath, "game.swf");

        const node = await dm.open(swfPath);
        if (!node || !node.content)
          throw new Error("'game.swf' not found or is empty.");

        if (this._currentBlobUrl) URL.revokeObjectURL(this._currentBlobUrl);
        this._currentBlobUrl = URL.createObjectURL(node.content);

        player.load({ url: this._currentBlobUrl });

        if (window.SystemGamepad) {
          window.SystemGamepad.show();
        }

      } catch (error) {
        dialogHandler.spawnDialog({
          icon: "error",
          title: "Flash Error",
          text: `Could not load the game: ${error.message}`,
        });
        if (window.SystemGamepad) window.SystemGamepad.hide();
        wm.closeWindow(hWnd);
        return;
      }

      wm._windows[hWnd].addEventListener(
        "wm:windowClosed",
        () => {
          if (window.SystemGamepad) {
            window.SystemGamepad.hide();
          }

          if (this._currentBlobUrl) {
            URL.revokeObjectURL(this._currentBlobUrl);
            this._currentBlobUrl = null;
          }
        },
        { once: true },
      );

      return hWnd;
    },
  });
})();